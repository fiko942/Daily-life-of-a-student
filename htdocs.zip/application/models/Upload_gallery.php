<?php
class Upload_gallery extends CI_Model{
 
    function simpan_upload($judul,$image){
        $data = array(
                'title' => $judul,
                'img_name' => $image
            );  
        $result= $this->db->insert('galery',$data);
        return $result;
    }
     
}