 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <!DOCTYPE html>
 <html>

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="author" content="Fiko Tobel">
     <title>Login</title>
     <link rel="icon" href="<?= base_url() ?>assets/img/brand/favicon.png" type="image/png">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/swal/dist/sweetalert2.min.css">
     <link rel="stylesheet" href="<?= base_url() ?>assets/css/argon.css?v=1.1.0" type="text/css">
 </head>

 <body class="bg-default">
     <div class="main-content">
         <div class="header bg-gradient-primary py-7 py-lg-8">
             <div class="separator separator-bottom separator-skew zindex-100">
                 <svg x="0" y="0" viewBox="0 0 2560 100" preserveAspectRatio="none" version="1.1"
                     xmlns="http://www.w3.org/2000/svg">
                     <polygon class="fill-default" points="2560 0 2560 100 0 100"></polygon>
                 </svg>
             </div>
         </div>
         <div class="container mt--8 pb-5">
             <div class="row justify-content-center">
                 <div class="col-lg-5 col-md-7">
                     <div class="card bg-secondary border-0 mb-0">
                         <div class="card-body px-lg-3 py-lg-3">
                             <div class="text-center text-muted mb-2">
                                 <small>Please sign in for start your session</small>
                             </div>
                             <form role="form">
                                 <div class="form-group mb-3">
                                     <div class="input-group input-group-merge input-group-alternative">
                                         <div class="input-group-prepend">
                                             <span class="input-group-text"><span class="material-icons">
                                                     account_circle
                                                 </span></span>
                                         </div>
                                         <input onkeypress="enterHandler(event);" id="username" class="form-control"
                                             placeholder="Username" type="text">
                                     </div>
                                 </div>
                                 <div class="form-group">
                                     <div class="input-group input-group-merge input-group-alternative">
                                         <div class="input-group-prepend">
                                             <span class="input-group-text"><span class="material-icons">
                                                     lock
                                                 </span></span>
                                         </div>
                                         <input onkeypress="enterHandler(event);" id="password" class="form-control"
                                             placeholder="Password" type="password">
                                     </div>
                                 </div>
                                 <div class="text-center">
                                     <button onclick="login();" type="button" class="btn btn-primary my-2">Sign
                                         in</button>
                                 </div>
                             </form>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <script src="<?= base_url() ?>assets/vendor/jquery/dist/jquery.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/js-cookie/js.cookie.js"></script>
     <script src="<?= base_url() ?>assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
     <script src="<?= base_url() ?>assets/js/argon.js?v=1.1.0"></script>
     <script src="<?= base_url() ?>assets/vendor/swal/dist/sweetalert2.min.js"></script>
     <script type="text/javascript">
     function enterHandler(event) {
         if (event.keyCode === 13) {
             login();
         }
     }

     function login() {
         $.ajax({
             url: "<?= base_url() ?>login/ajax_login",
             type: "POST",
             data: {
                 "username": $("#username").val(),
                 "password": $("#password").val()
             },
             success: function(content) {
                 if (content == "success") {
                     document.location.href = "<?= base_url() ?>user";
                 } else {
                     Swal.fire(
                         '',
                         content,
                         'error'
                     );
                 }
             },
             error: function() {
                 Swal.fire(
                     '',
                     'Internal Server Error',
                     'error'
                 );
             }
         })
     }
     </script>
 </body>

 </html>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->