 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <!DOCTYPE html>
 <html>

 <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
     <meta name="author" content="Wiji Fiko Teren">
     <title><?= $name; ?></title>
     <link rel="icon" href="<?= base_url() ?>assets/img/brand/favicon.png" type="image/png">
     <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
     <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/nucleo/css/nucleo.css" type="text/css">
     <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/@fortawesome/fontawesome-free/css/all.min.css"
         type="text/css">
     <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/swal/dist/sweetalert2.min.css">
     <link rel="stylesheet" href="<?= base_url() ?>assets/css/argon.css?v=1.1.0" type="text/css">
     <link rel="stylesheet" href="<?= base_url() ?>assets/vendor/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
     <link rel="stylesheet"
         href="<?= base_url() ?>assets/vendor/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
     <link rel="stylesheet"
         href="<?= base_url() ?>assets/vendor/datatables.net-select-bs4/css/select.bootstrap4.min.css">
 </head>

 <body>
     <nav class="sidenav navbar navbar-vertical fixed-left navbar-expand-xs navbar-light bg-white" id="sidenav-main">
         <div class="scrollbar-inner">
             <div class="sidenav-header d-flex align-items-center">
                 <div class="ml-auto">
                     <div class="sidenav-toggler d-none d-xl-block" data-action="sidenav-unpin"
                         data-target="#sidenav-main">
                         <div class="sidenav-toggler-inner">
                             <i class="sidenav-toggler-line"></i>
                             <i class="sidenav-toggler-line"></i>
                             <i class="sidenav-toggler-line"></i>
                         </div>
                     </div>
                 </div>
             </div>
             <div class="navbar-inner">
                 <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                     <ul class="navbar-nav">
                         <li class="nav-item">
                             <a id="nav_editProfile" class="nav-link">
                                 <i class="material-icons text-primary">
                                     contacts
                                 </i>
                                 <span class="nav-link-text">Edit Profile</span>
                             </a>
                         </li>
                         <li class="nav-item">
                             <a id="nav_textNote" class="nav-link">
                                 <i class="material-icons text-orange">
                                     text_snippet
                                 </i>
                                 <span class="nav-link-text">Text Note</span>
                             </a>
                         </li>
                         <li class="nav-item">
                             <a id="nav_schoolWork" class="nav-link">
                                 <i class="material-icons text-green">
                                     school
                                 </i>
                                 <span class="nav-link-text">School Work</span>
                             </a>
                         </li>
                         <li class="nav-item">
                             <a id="nav_Gallery" class="nav-link">
                                 <i class="fas fa-images text-red"></i>
                                 <span class="nav-link-text">Gallery</span>
                             </a>
                         </li>
                         <li class="nav-item">
                             <a id="nav_UserLogout" class="nav-link">
                                 <i class="material-icons">
                                     highlight_off
                                 </i>
                                 <span class="nav-link-text">Logout</span>
                             </a>
                         </li>
                     </ul>
                 </div>
             </div>
         </div>
     </nav>
     <div class="main-content" id="panel"></div>
     <script src="<?= base_url() ?>assets/vendor/jquery/dist/jquery.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/js-cookie/js.cookie.js"></script>
     <script src="<?= base_url() ?>assets/vendor/jquery.scrollbar/jquery.scrollbar.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/chart.js/dist/Chart.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/chart.js/dist/Chart.extension.js"></script>
     <script src="<?= base_url() ?>assets/js/argon.js?v=1.1.0"></script>
     <script src="<?= base_url() ?>assets/js/demo.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/swal/dist/sweetalert2.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net/js/jquery.dataTables.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-buttons/js/buttons.html5.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-buttons/js/buttons.flash.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-buttons/js/buttons.print.min.js"></script>
     <script src="<?= base_url() ?>assets/vendor/datatables.net-select/js/dataTables.select.min.js"></script>
     <script>
     document.getElementById("nav_editProfile").style.cursor = "pointer";
     document.getElementById("nav_textNote").style.cursor = "pointer";
     document.getElementById("nav_schoolWork").style.cursor = "pointer";
     document.getElementById("nav_Gallery").style.cursor = "pointer";
     document.getElementById("nav_UserLogout").style.cursor = "pointer";
     $("#nav_editProfile").on("click", function() {
         $("#panel").load("user/contentEditProfile");
     })

     $("#nav_textNote").on("click", function() {
         $("#panel").load("user/contentTextNote");
     })

     $("#nav_schoolWork").on("click", function() {
         $("#panel").load("user/contentSchoolWork");
     })

     $("#nav_Gallery").on("click", function() {
         $("#panel").load("user/contentGallery");
     })

     $("#nav_UserLogout").on("click", function() {
         window.location.href = "<?= base_url('user/logout') ?>";
     })

     $("#panel").load("user/contentEditProfile");
     <?= $this->session->flashdata("script"); ?>
     </script>
 </body>

 </html>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->