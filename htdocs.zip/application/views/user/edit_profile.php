 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <div class="header bg-primary pb-6">
     <div class="container-fluid">
         <div class="header-body">
             <div class="row align-items-center py-4">
             </div>
         </div>
     </div>
 </div>
 <div class="container-fluid mt--6">
     <div class="row">
         <div class="col-lg-12">
             <div class="card-wrapper">
                 <div class="card">
                     <div class="card-header">
                         <h3 class="mb-0">Edit Profile</h3>
                     </div>
                     <div class="card-body">
                         <form id="changeName">
                             <div class="row">
                                 <div class="col-md-12">
                                     <div class="form-group">
                                         <div class="input-group input-group-merge">
                                             <div class="input-group-prepend">
                                                 <span class="input-group-text"><span class="material-icons">
                                                         face
                                                     </span></span>
                                             </div>
                                             <input id="name" class="form-control" placeholder="Your name" type="text"
                                                 value="<?= $name; ?>">
                                         </div>
                                     </div>
                                 </div>
                             </div>
                             <div class="form-group">
                                 <button type="submit" class="btn btn-primary" style="float: rigt;">Submit</button>
                             </div>
                         </form>
                     </div>
                 </div>
             </div>
         </div>
     </div>

     <div class="row">
         <div class="col-lg-12">
             <div class="card-wrapper">
                 <div class="card">
                     <div class="card-header">
                         <h3 class="mb-0">Change password</h3>
                     </div>
                     <div class="card-body">
                         <form id="changePassword">
                             <div class="row">
                                 <div class="col-md-6">
                                     <div class="form-group">
                                         <div class="input-group input-group-merge">
                                             <div class="input-group-prepend">
                                                 <span class="input-group-text"><span class="material-icons">
                                                         vpn_key
                                                     </span></span>
                                             </div>
                                             <input id="new_password" class="form-control" placeholder="New password"
                                                 type="password">
                                         </div>
                                     </div>
                                 </div>
                                 <div class="col-md-6">
                                     <div class="form-group">
                                         <div class="input-group input-group-merge">
                                             <div class="input-group-prepend">
                                                 <span class="input-group-text"><span class="material-icons">
                                                         vpn_key
                                                     </span></span>
                                             </div>
                                             <input id="confirm_password" class="form-control"
                                                 placeholder="Confirm new password" type="password">
                                         </div>
                                     </div>
                                 </div>

                             </div>
                             <div class="form-group">
                                 <button type="submit" class="btn btn-primary" style="float: rigt;">Submit</button>
                             </div>
                         </form>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <script>
     $("#changeName").on("submit", function(event) {
         event.preventDefault();
         const name = $("#name").val();
         $.ajax({
             url: "user/change_name",
             type: "POST",
             data: {
                 "name": name
             },
             success: function(content) {
                 if (content == "success") {
                     window.location.href = window.location.href;
                 } else {
                     Swal.fire(
                         "",
                         content,
                         "error"
                     );
                 }
             },
             error: function(xhr, ajaxOptions, thrownError) {
                 Swal.fire(
                     xhr.status,
                     thrownError,
                     'error'
                 );
             }
         })
     })

     $("#changePassword").on("submit", function(event) {
         event.preventDefault();
         const new_password = $("#new_password").val();
         const confirm_password = $("#confirm_password").val();
         $.ajax({
             url: "user/change_password",
             type: "POST",
             data: {
                 "new_password": new_password,
                 "confirm_password": confirm_password
             },
             success: function(content) {
                 if (content == "Your password has been updated successfully!") {
                     Swal.fire(
                         "",
                         content,
                         "success"
                     );
                     $("#new_password").val("");
                     $("#confirm_password").val("");
                 } else {
                     Swal.fire(
                         "",
                         content,
                         "error"
                     );
                 }
             },
             error: function(xhr, ajaxOptions, thrownError) {
                 Swal.fire(
                     xhr.status,
                     thrownError,
                     'error'
                 );
             }
         })
     })
     </script>
     <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->