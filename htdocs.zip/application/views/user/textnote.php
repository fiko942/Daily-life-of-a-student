 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <div class="header bg-primary pb-6">
     <div class="container-fluid">
         <div class="header-body">
             <div class="row align-items-center py-4">
             </div>
         </div>
     </div>
 </div>
 <div class="container-fluid mt--6">
     <div class="row">
         <div class="col">
             <div class="card">
                 <div class="card-header">
                     <div class="row">
                         <div class="col">
                             <h3 class="mb-0">Text Note</h3>
                         </div>
                         <div class="col">
                             <button type="button" class="btn btn-primary btn-icon" style="float: right;"
                                 data-toggle="modal" data-target="#add_note">
                                 <span class="btn-inner--icon"><i class="fas fa-plus"></i></span>
                                 <span class="btn-inner--text">Add new note</span>
                             </button>
                         </div>
                     </div>
                 </div>
                 <?php 
function tenc($string, $action = 'e')
        {
            $encrypt_method = "AES-256-CBC";
            $secret_key = 'AA74CDCC2BBRT935136HH7B63C27';
            $secret_iv = '5fgf5HJ5g27'; 
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16); 
            if ($action == 'e') {
                $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
            } else if ($action == 'd') {
                $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
            }
            return $output;
        }
?>
                 <div class="table-responsive py-4">
                     <div id="tabel">
                         <table class="table table-flush" id="datatable-buttons">
                             <thead class="thead-light">
                                 <tr>
                                     <th>#</th>
                                     <th>Title</th>
                                     <th>Text</th>
                                     <th>Action</th>
                                 </tr>
                             </thead>
                             <tfoot>
                                 <tr>
                                     <th>#</th>
                                     <th>Title</th>
                                     <th>Text</th>
                                     <th>Action</th>
                                 </tr>
                             </tfoot>
                             <tbody>

                                 <?php $i = 1; ?>
                                 <?php foreach($note as $n) : ?>
                                 <tr>
                                     <td><?= $i; ?></td>
                                     <td><?= trim(htmlspecialchars(tenc($n["title"], "d"))); ?></td>
                                     <td><?= substr(trim(htmlspecialchars(tenc($n["text"], "d"))), 0, 10); ?>...</td>
                                     <td>
                                         <div class="row">
                                             <div class="col"><button type="button" onclick="edit(<?= $n['id'] ?>)"
                                                     class="btn btn-primary btn-sm" data-dismiss="modal">Edit</button>
                                             </div>

                                             <div class="col"><button type="button" onclick="view(<?= $n['id'] ?>);"
                                                     class="btn btn-success btn-sm" data-dismiss="modal">View</button>
                                             </div>

                                             <div class="col"><button type="button"
                                                     onclick="delete_note('<?= $n['id'] ?>', '<?= trim(htmlspecialchars(tenc($n['title'], "d"))) ?>')"
                                                     class="btn btn-danger btn-sm" data-dismiss="modal">Delete</button>
                                             </div>
                                         </div>
                                     </td>
                                 </tr>
                                 <?php $i++; ?>
                                 <?php endforeach; ?>
                     </div>
                     </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <div class="modal fade" id="add_note" tabindex="-1" role="dialog" aria-labelledby="add_note" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <div class="form-group">
                     <label class="form-control-label">Title</label>
                     <input onkeypress="enterHandler(event)" id="field_title" class="form-control form-control-sm"
                         type="text" placeholder="Title">
                 </div>

                 <div class="form-group">
                     <label class="form-control-label">Text</label>
                     <textarea id="field_text" class="form-control form-control-sm" type="text" placeholder="Text"
                         rows="10"></textarea>
                 </div>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                 <button type="button" onclick="add_note();" class="btn btn-primary btn-sm">Save</button>
             </div>
         </div>
     </div>
 </div>
 <div class="modal fade" id="modal_edit" tabindex="-1" role="dialog" aria-labelledby="modal_edit" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Edit Note</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <input type="hidden" id="edit_id">
                 <div class="form-group">
                     <label class="form-control-label">Text</label>
                     <textarea id="edit_text" class="form-control form-control-sm" type="text" placeholder="Text"
                         rows="10"></textarea>
                 </div>
             </div>
             <div class="modal-footer">
                 <button onclick="edit_now()" type="button" class="btn btn-primary btn-sm">Save changes</button>
             </div>
         </div>
     </div>
 </div>
 <div class="modal fade" id="modal_view" tabindex="-1" role="dialog" aria-labelledby="modal_view" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLongTitle">View Note</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <p id="edit_content">
                     ....
                 </p>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
             </div>
         </div>
     </div>
 </div>
 <script type="text/javascript">
function enterHandler(event) {
    if (event.keyCode === 13) {
        add_note();
    }
}

function add_note() {
    $.ajax({
        url: "user/add_note",
        type: "POST",
        data: {
            "title": $("#field_title").val(),
            "text": $("#field_text").val()
        },
        success: function(content) {
            if (content == "Note has been added successfully") {
                $.ajax({
                    url: "",
                    context: document.body,
                    success: function(s, x) {
                        $(this).html(s);
                    }
                });
            } else {
                Swal.fire(
                    '',
                    content,
                    'error'
                );
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}

function edit_now() {
    const id = $("#edit_id").val();
    const text = $("#edit_text").val();

    $.ajax({
        url: "user/edit_note_now",
        type: "POST",
        data: {
            "id": id,
            "text": text
        },
        success: function(content) {
            if (content == "success") {
                location.reload();
            } else {
                Swal.fire(
                    "",
                    content,
                    'error'
                );
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })

}

function edit(id) {
    $.ajax({
        url: "user/edit_note",
        type: "POST",
        data: {
            "id": id
        },
        success: function(value) {
            $("#modal_edit").modal("show");
            $("#edit_text").val(value);
            $("#edit_id").val(id);
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}

function view(id) {
    $.ajax({
        url: "user/view_note",
        type: "POST",
        data: {
            "id": id
        },
        success: function(content) {
            $("#modal_view").modal("show");
            $("#edit_content").html(content.replace(/(?:\r\n|\r|\n)/g, '<br>'));
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}


function delete_note(id, title) {
    Swal.fire({
        title: 'Are you sure to delete note ' + title + ' ?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "user/delete_note",
                type: "POST",
                data: {
                    "id": id,
                    "title": title
                },
                success: function(msg) {
                    if (msg == "success") {
                        location.reload();
                    } else {
                        Swal.fire(
                            "",
                            msg,
                            'error'
                        );
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    Swal.fire(
                        xhr.status,
                        thrownError,
                        'error'
                    );
                }
            })
        }
    })
}
 </script>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->