 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <div class="header bg-primary pb-6">
     <div class="container-fluid">
         <div class="header-body">
             <div class="row align-items-center py-4">
             </div>
         </div>
     </div>
 </div>
 <div class="container-fluid mt--6">
     <div class="row justify-content-center">
         <div class="col-lg-12">
             <div class="card">
                 <div class="card-header bg-transparent">
                     <h3 class="mb-0">Upload Pictures</h3>
                 </div>
                 <form class="form-horizontal col-lg-12" id="upload_image">
                     <div class="form-group">
                         <input type="text" name="judul" class="form-control" placeholder="Title">
                     </div>
                     <div class="form-group">
                         <input type="file" name="file">
                     </div>
                     <div class="form-group">
                         <button class="btn btn-primary" id="btn_upload" type="submit">Upload now</button>
                     </div>
                 </form>
             </div>
         </div>
     </div>
 </div>
 <style>
.portfolio-menu {
    text-align: center;
}

.portfolio-menu ul li {
    display: inline-block;
    margin: 0;
    list-style: none;
    padding: 10px 15px;
    cursor: pointer;
    -webkit-transition: all 05s ease;
    -moz-transition: all 05s ease;
    -ms-transition: all 05s ease;
    -o-transition: all 05s ease;
    transition: all .5s ease;
}

.portfolio-item .item {
    float: left;
    margin-bottom: 10px;
}
 </style>
 <div class="container">
     <div class="portfolio-item row">

         <?php foreach($pictures as $p) : ?>
         <div class="item selfie col-lg-3 col-md-4 col-6 col-sm">
             <a href="<?= base_url('user/view_galery?p=') . str_replace(" ", "_", $p["title"]); ?>" target="_blank"
                 class="fancylight popup-btn" data-fancybox-group="light">
                 <img class="img-fluid" width="150" height="150"
                     src="<?= base_url('user/view_thumbnail?p=') . str_replace(" ", "_", $p["title"]); ?>">
             </a>
         </div>
         <?php endforeach; ?>

     </div>
 </div>

 <script type="text/javascript">
$(document).ready(function() {
    $('#upload_image').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: '<?php echo base_url();?>user/upload_gallery',
            type: "post",
            data: new FormData(this),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data) {
                if (data == "success") {
                    location.reload();
                } else {
                    Swal.fire(
                        "",
                        data,
                        'error'
                    );
                }
            }
        });
    });
});

$('.portfolio-menu ul li').click(function() {
    $('.portfolio-menu ul li').removeClass('active');
    $(this).addClass('active');

    var selector = $(this).attr('data-filter');
    $('.portfolio-item').isotope({
        filter: selector
    });
    return false;
});
$(document).ready(function() {
    var popup_btn = $('.popup-btn');
    popup_btn.magnificPopup({
        type: 'image',
        gallery: {
            enabled: true
        }
    });
});
 </script>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->