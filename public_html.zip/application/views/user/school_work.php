 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <div class="header bg-primary pb-6">
     <div class="container-fluid">
         <div class="header-body">
             <div class="row align-items-center py-4">
             </div>
         </div>
     </div>
 </div>
 <div class="container-fluid mt--7">
     <div class="card mb-4">
     </div>
     <div class="row">
         <div class="col-lg-12">
             <div class="card-wrapper">
                 <div class="card">
                     <div class="card-header">
                         <button type="button" class="btn btn-primary btn-icon" style="float: right;"
                             data-toggle="modal" data-target="#addSchoolWork">
                             <span class="btn-inner--icon"><i class="fas fa-plus"></i></span>
                             <span class="btn-inner--text">Add new school work</span>
                         </button>
                         <h3 class="mb-0">School Work</h3>
                     </div>
                     <div class="card-body">
                         <?php 
function tenc($string, $action = 'e')
        {
            $encrypt_method = "AES-256-CBC";
            $secret_key = 'AA74CDCC2BBRT935136HH7B63C27';
            $secret_iv = '5fgf5HJ5g27'; 
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16); 
            if ($action == 'e') {
                $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
            } else if ($action == 'd') {
                $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
            }
            return $output;
        }
?>
                         <table class="table table-flush" id="datatable-buttons">
                             <thead class="thead-light">
                                 <tr>
                                     <th>#</th>
                                     <th>Course</th>
                                     <th>Description</th>
                                     <th>Deadline</th>
                                     <th>Status</th>
                                     <th>Set Status</th>
                                     <th>Action</th>
                                 </tr>
                             </thead>
                             <tfoot>
                                 <tr>
                                     <th>#</th>
                                     <th>Course</th>
                                     <th>Description</th>
                                     <th>Deadline</th>
                                     <th>Status</th>
                                     <th>Set Status</th>
                                     <th>Action</th>
                                 </tr>
                             </tfoot>
                             <tbody>
                                 <?php $i = 1; ?>
                                 <?php foreach($school_work as $sw) : ?>
                                 <tr>
                                     <td><?= $i; ?></td>
                                     <td><?= htmlspecialchars($sw["course"]); ?></td>
                                     <td><?= substr(trim(htmlspecialchars(tenc($sw["description"], "d"))), 0, 10); ?>[<a
                                             style="cursor: pointer; color: red;"
                                             onclick="viewDescription(<?= $sw['id'] ?>);">View More</a>]...</td>
                                     <td><?= trim(htmlspecialchars($sw["deadline"])); ?></td>
                                     <?php if ($sw["status"] == "Pending") : ?>
                                     <td><span class="badge badge-dot mr-4">
                                             <i class="bg-danger"></i>
                                             <span class="status">Pending</span>
                                         </span></td>
                                     <?php elseif ($sw["status"] == "Working") : ?>
                                     <td><span class="badge badge-dot mr-4">
                                             <i class="bg-primary"></i>
                                             <span class="status">Working</span>
                                         </span></td>
                                     <?php elseif($sw["status"] == "Finished") : ?>
                                     <td><span class="badge badge-dot mr-4">
                                             <i class="bg-success"></i>
                                             <span class="status">Finished</span>
                                         </span></td>
                                     <?php endif; ?>
                                     <td>
                                         <select class="form-control-sm" data-toggle="select"
                                             onchange="change_status(<?= $sw['id'] ?>, $(this).val())" id="set_status">
                                             <option value="Pending"
                                                 <?php if($sw["status"] == "Pending") { echo "selected"; } ?>>Pending
                                             </option>
                                             <option value="Working"
                                                 <?php if($sw["status"] == "Working") { echo "selected"; } ?>>Working
                                             </option>
                                             <option value="Finished"
                                                 <?php if($sw["status"] == "Finished") { echo "selected"; } ?>>
                                                 Finished</option>
                                         </select>
                                     </td>
                                     <td>
                                         <?php $course = htmlspecialchars($sw["course"]); ?>
                                         <button onclick="work_delete(<?= $sw['id'] ?>, '<?= $course ?>')" type="button"
                                             class="btn btn-danger btn-icon-only rounded-circle">
                                             <span class="btn-inner--icon"><i class="material-icons">
                                                     delete
                                                 </i></span>
                                         </button>
                                     </td>
                                 </tr>
                                 <?php $i++; ?>
                                 <?php endforeach; ?>
                             </tbody>
                         </table>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 </div>
 <div class="modal fade" id="addSchoolWork" tabindex="-1" role="dialog" aria-labelledby="addSchoolWork"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabel">Add School Work</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <div class="form-group row">
                     <label for="example-text-input" class="col-md-2 col-form-label form-control-label">Course</label>
                     <div class="col-md-10">
                         <input class="form-control" type="text" id="field_course">
                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="example-text-input" class="col-md-2 col-form-label form-control-label">Desc</label>
                     <div class="col-md-10">
                         <textarea class="form-control" type="text" id="field_description"></textarea>
                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="example-text-input" class="col-md-2 col-form-label form-control-label">Status</label>
                     <div class="col-md-10">
                         <select class="form-control" data-toggle="select" id="field_status">
                             <option value="Pending">Pending</option>
                             <option value="Working">Working</option>
                             <option value="Finished">Finished</option>
                         </select>
                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="field_deadline" class="col-md-2 col-form-label form-control-label">Deadline</label>
                     <div class="col-md-10">
                         <input class="form-control" type="datetime-local" id="field_deadline"
                             value="2021-11-23T10:30:00">
                     </div>
                 </div>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
                 <button onclick="addSchoolWork()" type="button" class="btn btn-primary btn-sm">Save changes</button>
             </div>
         </div>
     </div>
 </div>
 <div class="modal fade" id="modal_view" tabindex="-1" role="dialog" aria-labelledby="modal_view" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLongTitle">View Description</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <p id="edit_content">
                     ....
                 </p>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
             </div>
         </div>
     </div>
 </div>
 <script type="text/javascript">
function addSchoolWork() {
    const course = $("#field_course").val();
    const desc = $("#field_description").val();
    const status = $("#field_status").val();
    const deadline = $("#field_deadline").val();

    $.ajax({
        url: "user/add_school_work",
        type: "POST",
        data: {
            "course": course,
            "desc": desc,
            "status": status,
            "deadline": deadline
        },
        success: function(msg) {
            if (msg == "success") {
                location.reload();
            } else {
                Swal.fire(
                    "",
                    msg,
                    'error'
                );
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}

function change_status(id, val) {
    $.ajax({
        url: "user/change_status",
        type: "POST",
        data: {
            "id": id,
            "value": val
        },
        success: function(msg) {
            if (msg == "success") {
                location.reload();
            } else {
                Swal.fire(
                    "",
                    msg,
                    'error'
                );
            }
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}

function viewDescription(id) {
    $.ajax({
        url: "user/view_description",
        type: "POST",
        data: {
            "id": id
        },
        success: function(content) {
            $("#modal_view").modal("show");
            $("#edit_content").html(content.replace(/(?:\r\n|\r|\n)/g, '<br>'));
        },
        error: function(xhr, ajaxOptions, thrownError) {
            Swal.fire(
                xhr.status,
                thrownError,
                'error'
            );
        }
    })
}

function work_delete(id, course) {
    Swal.fire({
        title: 'Are you sure to delete work ' + course + ' ?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "user/delete_work",
                type: "POST",
                data: {
                    "id": id
                },
                success: function(msg) {
                    if (msg == "success") {
                        location.reload();
                    } else {
                        Swal.fire(
                            "",
                            msg,
                            'error'
                        );
                    }
                },
                error: function(xhr, ajaxOptions, thrownError) {
                    Swal.fire(
                        xhr.status,
                        thrownError,
                        'error'
                    );
                }
            })
        }
    })
}
 </script>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->