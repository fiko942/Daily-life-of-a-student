 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->
 <?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
 <!DOCTYPE html>
 <html>

 <head>
     <title>Oops ...</title>
 </head>
 <style type="text/css">
@import url('https://fonts.googleapis.com/css2?family=Fira+Code:wght@300;400;500;600&display=swap');

@mixin breakpoint($point) {
    @if $point==mobile {
        @media (max-width: 480px) and (min-width: 320px) {
            @content ;
        }
    }
}

@keyframes floating {
    from {
        transform: translateY(0px);
    }

    65% {
        transform: translateY(15px);
    }

    to {
        transform: translateY(-0px);
    }
}

body,
html {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

html {
    height: 100%;
    font-family: 'Fira Code', monospace;
}

body {
    font-family: 'Fira Code', monospace;
    background-image: url('https://assets.codepen.io/1538474/star.svg'), linear-gradient(to bottom, #05007A, #4D007D);
    height: 100%;
    margin: 0;
    background-attachment: fixed;
    overflow: hidden;
}

.mars {
    left: 0;
    right: 0;
    bottom: 0;
    position: absolute;
    height: 27vmin;
    background: url('https://assets.codepen.io/1538474/mars.svg') no-repeat bottom center;
    background-size: cover;
}

.logo-404 {
    position: absolute;
    margin-left: auto;
    margin-right: auto;
    left: 0;
    right: 0;
    top: 16vmin;
    width: 30vmin;

    @include breakpoint(mobile) {
        top: 45vmin;
    }
}

.meteor {
    position: absolute;
    right: 2vmin;
    top: 16vmin;
}

.title {
    color: white;
    font-weight: 600;
    text-align: center;
    font-size: 5vmin;
    margin-top: 31vmin;

    @include breakpoint(mobile) {
        margin-top: 65vmin;
    }
}

.subtitle {
    color: white;
    font-weight: 400;
    text-align: center;
    font-size: 3.5vmin;
    margin-top: -1vmin;
    margin-bottom: 9vmin;
}

.btn-back {
    border: 1px solid white;
    color: white;
    height: 5vmin;
    padding: 12px;
    text-decoration: none;
    border-radius: 5px;

    &:hover {
        background: white;
        color: #4D007D;
    }

    @include breakpoint(mobile) {
        font-size: 3.5vmin;
    }
}

.astronaut {
    position: absolute;
    top: 18vmin;
    left: 10vmin;
    height: 30vmin;
    animation: floating 3s infinite ease-in-out;

    @include breakpoint(mobile) {
        top: 2vmin;
    }
}

.spaceship {
    position: absolute;
    bottom: 15vmin;
    right: 24vmin;

    @include breakpoint(mobile) {
        width: 45vmin;
        bottom: 18vmin;
    }
}
 </style>

 <body>
     <div class="mars"></div>
     <img src="https://daily.tobelsoft.my.id/assets/svg/meteor.svg" class="meteor" />
     <p class="title"><?php echo "A PHP Error was encountered" ?></p>
     <p class="subtitle">
         Severity: <?php echo $severity; ?>
         Message: <?php echo $message; ?>
         Filename: <?php echo $filepath; ?>
         Line Number: <?php echo $line; ?>
     </p>
     <div align="center">
         <a class="btn-back" href="./">Back to home</a>
     </div>
     <img src="https://daily.tobelsoft.my.id/assets/svg/astronaut.svg" class="astronaut" />
     <img src="https://daily.tobelsoft.my.id/assets/svg/spaceship.svg" class="spaceship" />
 </body>

 </html>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->