 <!-- =========================================================
 * Daily life of a student
 =========================================================
 * Github Repository : https://github.com/fiko942/Daily-life-of-a-student
 * Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
 * Coded by Wiji Fiko Teren
 * Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
 * Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
 * Thanks for downloading ...
 =========================================================
  -->
 <?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata("username")){
			$user = $this->db->get_where("user", ["username" => $this->session->userdata("username")])->row_array();
			if(!$user) {
				$this->session->unset_userdata("username");
                redirect("login");
			} 
		} else {
            redirect("login");
        }
        $this->load->model('upload_gallery');
    }
    public function view_description(){
        $id = $this->input->post("id");
        if(!isset($id)) {
            echo "Id is not set"; die;
        } elseif (empty($this->input->post("id"))){
            echo "Id is required, cannot be empty"; die;
        } else {
            $result = $this->db->get_where("school_work", ["id" => $id])->row_array();
            if(!$result){
                echo 'School work with id '. $id .' is not found!'; die;
            } else {
                echo htmlspecialchars($this->tenc($result["description"],"d"));
            }
        }
    }
    public function logout(){
        $this->session->unset_userdata("username");
        redirect("login");
    }
    function object_to_array($data)
    {
        if (is_array($data) || is_object($data))
        {
            $result = [];
            foreach ($data as $key => $value)
            {
                $result[$key] = (is_array($data) || is_object($data)) ? object_to_array($value) : $value;
            }
            return $result;
        }
        return $data;
    }
     private function tenc($string, $action = 'e')
        {
            $encrypt_method = "AES-256-CBC";
            $secret_key = 'AA74CDCC2BBRT935136HH7B63C27';
            $secret_iv = '5fgf5HJ5g27'; 
            $key = hash('sha256', $secret_key);
            $iv = substr(hash('sha256', $secret_iv), 0, 16); 
            if ($action == 'e') {
                $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
                $output = base64_encode($output);
            } else if ($action == 'd') {
                $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
            }
            return $output;
        }
    private function toutf8($value)
        {
          return mb_convert_encoding($value, "UTF-8");;
        }
    function upload_gallery(){
        $title = $this->input->post("judul");
        if(empty($title)){
            echo "Title is required, cannot be empty"; die;
        } elseif (strlen($title) < 7){
            echo "Enter title field above 7 characters"; die;
        } elseif (strlen($title) > 50){
            echo "Enter title field under 50 characters"; die;
        } else {
            $config['upload_path']="./assets/images";
            $config['allowed_types']='gif|jpg|png|ico|GIF|JPG|PNG|ICO';
            $config['encrypt_name'] = TRUE;
            $this->load->library('upload',$config);
            if($this->upload->do_upload("file")){
                $data = array('upload_data' => $this->upload->data());
                $judul= $this->input->post('judul');
                $image= $data['upload_data']['file_name'];
                $result= $this->upload_gallery->simpan_upload($judul,$image);
                $this->resizeImage($image);
            }
            $this->session->set_flashdata("script", '$("#panel").load("user/contentGallery");
                   
            Swal.fire(
             "",
             "Picture has been uploaded successfully",
             "success"
             );
             $("#panel").load("user/contentGallery");
             $("#panel").load("user/contentGallery");
            ');
                 echo "success";
        }
    }
     public function resizeImage($filename)
       {
          $source_path = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/' . $filename;
          $target_path = $_SERVER['DOCUMENT_ROOT'] . '/assets/images/thumbnail/';
          $config_manip = array(
              'image_library' => 'gd2',
              'source_image' => $source_path,
              'new_image' => $target_path,
              'maintain_ratio' => TRUE,
              'create_thumb' => TRUE,
              'thumb_marker' => '_thumb',
              'width' => 150,
              'height' => 150
          );
          $this->load->library('image_lib', $config_manip);
          if (!$this->image_lib->resize()) {
              echo $this->image_lib->display_errors();
          }
    
    
          $this->image_lib->clear();
       }
    public function view_galery(){
        $p = trim($this->input->get("p"));
        if(!isset($p)){
            redirect("user");
        } elseif (empty($p)){
            redirect("user");
        } else {
            $p2 = str_replace("_", " ", $p);
            $result = $this->db->get_where("galery", ["title" => $p2])->row_array();
            if(!$result){
                redirect("user"); die;
            } else {
                header("Content-type: image");
                echo file_get_contents(base_url("assets/images/" . $result["img_name"]));
            }
        }
    }
     public function view_thumbnail(){
        $p = trim($this->input->get("p"));
        if(!isset($p)){
            redirect("user");
        } elseif (empty($p)){
            redirect("user");
        } else {
            $p2 = str_replace("_", " ", $p);
            $result = $this->db->get_where("galery", ["title" => $p2])->row_array();
            if(!$result){
                redirect("user"); die;
            } else {
                header("Content-type: image");
                $imgname1 = $result["img_name"];
                $imgname2 = substr($imgname1,0,-4);
                $imgname3 = "_thumb";
                $imgname4 = substr($imgname1,-4);
                echo file_get_contents(base_url("assets/images/thumbnail/" . $imgname2 . $imgname3 . $imgname4));
            }
        }
    }

    public function contentGallery(){
        $this->db->order_by("id", "DESC");
        $data["pictures"] = $this->db->get_where("galery")->result_array();
        $this->load->view("user/gallery", $data);
    }

    public function change_name()
    {
        $name = $this->input->post("name");
        if(!isset($name)){
            echo "Parameter 'name' is required"; die;
        } elseif (empty($name)) {
            echo "Name is required, cannot be empty"; die;
        } elseif (strlen($name) < 4){
            echo "Enter name field above 4 characters"; die;
        } elseif (strlen($name) > 25){
            echo"Enter name field under 25 characters"; die;
        } else {
            $this->db->set("name", $this->tenc($name, "e"));
            $this->db->where("username", $this->session->userdata("username"));
            $q = $this->db->update("user");
            if($q){
                echo "success"; die;
            } else {
                echo "Error occured while change your name!"; die;
            }
        }
    }
    public function contentTextNote()
    {
        $this->db->order_by("id", "DESC");
        $data["note"] = $this->db->get_where("note_text")->result_array();
        $this->load->view("user/textnote", $data);
    }
    public function change_password()
    {
        $new_p = $this->input->post("new_password");
        $conf_p = $this->input->post("confirm_password");

        if(!isset($new_p) || !isset($conf_p)){
            echo "Parameter new password or confirm password is not set"; die;
        } elseif (empty($new_p)){
            echo "New password is required, cannot be empty"; die;
        } elseif (empty($conf_p)){
            echo "Confirm password is required, cannot be empty"; die;
        } elseif (strlen($new_p) < 7){
            echo "Please enter new password above 7 characters"; die;
        } elseif (strlen($conf_p > 40)){
            echo "Please enter new password above 40 characters"; die;
        } elseif ($new_p != $conf_p){
            echo "Confirm password is not matches!"; die;
        } else {
            $password_hashed = password_hash($new_p, PASSWORD_DEFAULT);
            $this->db->set("password", $password_hashed);
            $this->db->where("username", $this->session->userdata("username"));
            $q = $this->db->update("user");
            if($q){
                echo "Your password has been updated successfully!"; die;
            } else {
                echo "Error occured while updating yor password, please contact developer for more help!"; die;
            }
        }
    }
    public function edit_note_now()
    {
        $id = trim($this->input->post("id"));
        $text = trim($this->input->post("text"));
        if(!is_numeric($id)){
            echo "id is not valid"; die;
        } elseif (empty($id)) {
            echo "id cannot be empty"; die;
        } elseif (strlen($id) > 11){
            echo "id is not valid"; die;
        } elseif (strlen($text) < 10) {
            echo "Enter text field above 10 characters"; die;
        } elseif (strlen($text) > 999999999) {
            echo "Enter text field under 999999999 characters"; die;
        } else {
            $result = $this->db->get_where("note_text", ["id" => $id])->row_array();
            if(!$result){
                echo "Note is not found";
            } else {
                $this->db->set("text", $this->tenc($text, "e"));
                $this->db->where("id", $id);
                $query = $this->db->update("note_text");

                $title_menu = $result["title"];
                if($query){
                    $this->session->set_flashdata("script", '$("#panel").load("user/contentTextNote");
                   
               Swal.fire(
                "",
                "Note '. htmlspecialchars($this->tenc($title_menu, "d")) .' has been changed successfully",
                "success"
                );
                $("#panel").load("user/contentTextNote");
                $("#panel").load("user/contentTextNote");
               ');
                    echo "success";
                } else {
                    echo "Error occured while changing note with id " . $id; die;
                }
            }
        }
    }
    public function view_note(){
        $id = trim($this->input->post("id"));
        if(!is_numeric($id)){
            echo "id is not valid"; die;
        } elseif (empty($id)){
            echo "id is not valid"; die;
        } elseif (strlen($id) > 11){
            echo "id is not valid"; die;
        } else {
            $result  = $this->db->get_where("note_text", ["id" => $id])->row_array();
            if(!$result){
                echo "note is not found!"; die;
            } else {
                $text = $result["text"];
                echo htmlspecialchars($this->tenc($text, "d")); die;
            }
        }
    }
    public function change_status(){
        $id = trim($this->input->post("id"));
        $value = trim($this->input->post("value"));

        $result = $this->db->get_where("school_work", ["id" => $id])->row_array();
        if(!$result){
            echo "School work is not found"; die;
        } else {
            if($value != "Pending" && $value != "Working" && $value != "Finished"){
                echo "Value is not valid"; die;
            } else {
                $this->db->set("status", $value);
                $this->db->where("id", $id);
                $query = $this->db->update("school_work");
                if($query){

                    $this->session->set_flashdata("script", '$("#panel").load("user/contentSchoolWork");
                   
                    Swal.fire(
                     "",
                     "Status has been changed successfully",
                     "success"
                     );
                     $("#panel").load("user/contentSchoolWork");
                     $("#panel").load("user/contentSchoolWork");
                    ');

                    echo "success";
                } else {
                    echo "Error occured while updating status value"; die;
                }
            }
        }
    }
    public function delete_note(){
        $id = trim($this->input->post("id"));
        if(!is_numeric($id)){
            echo "id is not valid"; die;
        } elseif (empty($id)){
            echo "id is not valid"; die;
        } elseif (strlen($id) > 11){
            echo "id is not valid"; die;
        } else {
            $result  = $this->db->get_where("note_text", ["id" => $id])->row_array();
            if(!$result){
                echo "note is not found!"; die;
            } else {
                $query = $this->db->delete("note_text", ['id' => $id]);
                if($query){
                $title = trim(htmlspecialchars($this->input->post("title")));

                    $this->session->set_flashdata("script", '$("#panel").load("user/contentTextNote");
                   
               Swal.fire(
                "",
                "Note '. htmlspecialchars($title) .' has been deleted successfully",
                "success"
                );
                $("#panel").load("user/contentTextNote");
                $("#panel").load("user/contentTextNote");
               ');

                    echo "success";
                } else {
                    echo "Error occured while deleting this note"; die;
                }
            }
        }
    }
    public function contentSchoolWork(){
        $this->db->order_by("id", "DESC");
        $data["school_work"] = $this->db->get_where("school_work")->result_array();
        $this->load->view('user/school_work', $data);
    }
    public function add_school_work(){
        $course = trim($this->input->post("course"));
        $desc = trim($this->input->post("desc"));
        $status = trim($this->input->post("status"));
        $deadline = str_replace("T", " ", trim($this->input->post("deadline")));
        if(empty($course)){
            echo "Course field is required, cannot be empty"; die;
        } elseif (strlen($course) < 3) {
            echo "Enter course field above 3 characters"; die;
        } elseif (strlen($course) > 50) {
            echo "Enter course field under 50 characters"; die;
        } elseif (empty($desc)){
            echo "Description field is required, cannot be empty"; die;
        } elseif (strlen($desc) < 7){
            echo "Enter description field above 7 characters"; die;
        } elseif(strlen($desc) > 255){
            echo "Enter description field uner 255 characters"; die;
        } elseif ($status != "Pending" && $status != "Working" && $status != "Finished"){
            echo "Status is not valid"; die;
        } elseif(empty($deadline)){
            echo "Deadline is required, cannot be empty"; die;
        } else {
            
            $this->db->set("course", $course);
            $this->db->set("description", $this->tenc($desc, "e"));
            $this->db->set("deadline", $deadline);
            $this->db->set("status", $status);
            $query = $this->db->insert("school_work");
            if($query){
                $this->session->set_flashdata("script", '$("#panel").load("user/contentSchoolWork");
                   
               Swal.fire(
                "",
                "Course '. htmlspecialchars($course) .' has been added successfully",
                "success"
                );
                $("#panel").load("user/contentSchoolWork");
                $("#panel").load("user/contentSchoolWork");
               ');
               echo "success"; die;
            } else {
                echo "Error occured while adding school work record, please contact developer for more help"; die;
            }
        }
    }
    public function add_note(){
        $title = trim($this->input->post("title"));
        $text = trim($this->input->post("text"));
        if(empty($title)){
            echo "Title is required, cannot be empty"; die;
        } elseif (empty($text)){
            echo "Text is required, cannot be empty"; die;
        } elseif (strlen($title) < 4) {
            echo "Enter title field above 4 characters"; die;
        } elseif (strlen($title) > 50){
            echo "Enter title field under 50 characters"; die;
        } elseif (strlen($text) < 10) {
            echo "Enter text field above 10 characters"; die;
        } elseif (strlen($text) > 999999999){
            echo "Enter text field under 999999999 characters"; die;
        } else {
            $this->db->set("title", $this->tenc($title, "e"));
            $this->db->set("text", $this->tenc($text, "e"));
            $q = $this->db->insert("note_text");
           if($q){
               $this->session->set_flashdata("script", '$("#panel").load("user/contentTextNote");
                   
               Swal.fire(
                "",
                "Note '. htmlspecialchars($title) .' has been added successfully",
                "success"
                );
                $("#panel").load("user/contentTextNote");
                $("#panel").load("user/contentTextNote");
               ');
               echo "Note has been added successfully"; die;
           } else {
            $this->session->set_flashdata("script", '$("#panel").load("user/contentTextNote");');
               echo "Error occured while adding new note, please contact developer for more help"; die;
           }
        }
    }
    public function delete_work(){
        $id = trim($this->input->post("id"));
        $result  = $this->db->get_where("school_work", ["id" => $id])->row_array();
        if(!$result) {
            echo "Work is not found"; die;
        } else {
            $query = $this->db->delete("school_work", ["id" => $id]);
            if($query){

                $this->session->set_flashdata("script", '$("#panel").load("user/contentSchoolWork");
                   
               Swal.fire(
                "",
                "Work has been deleted successfully",
                "success"
                );
                $("#panel").load("user/contentSchoolWork");
                $("#panel").load("user/contentSchoolWork");
               ');

                echo "success";
                die;
            } else {
                echo "Error occured while deleting this work, please contact developer for more help"; die;
            }
        }
    }
    public function edit_note()
    {
        $id = trim($this->input->post("id"));

        if(!is_numeric($id)){
            echo "id is not valid"; die;
        } elseif (empty($id)){
            echo "id is not valid"; die;
        } elseif (strlen($id) > 11) {
            echo "id is not valid"; die;
        } else {
            $result = $this->db->get_where("note_text", ['id' => $id])->row_array();
            if ($result == true){
                echo $this->tenc($result["text"], "d");
            } else {
                echo "id is not found";
            }
        }
    }
    public function contentEditProfile()
    {
        $data["user"] = $this->db->get_where("user", ["username" => $this->session->userdata("username")])->row_array();
        $data["name"] = $this->tenc($data["user"]["name"], "d");
        $this->load->view("user/edit_profile.php", $data);
    }
    public function index()
    {
        $data["user"] = $this->db->get_where("user", ["username" => $this->session->userdata("username")])->row_array();
        $data["name"] = $this->tenc($data["user"]["name"], "d");
        $this->load->view("user/base.php", $data);   
    }
}
?>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->