 <!-- =========================================================
 * Daily life of a student
 =========================================================
 * Github Repository : https://github.com/fiko942/Daily-life-of-a-student
 * Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
 * Coded by Wiji Fiko Teren
 * Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
 * Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
 * Thanks for downloading ...
 =========================================================
  -->
 <?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
	public function index()
	{
		$this->load->view('login/base.php');
	}
	public function __construct(){
        parent::__construct();
        if($this->session->userdata("username")){
			$user = $this->db->get_where("user", ["username" => $this->session->userdata("username")])->row_array();
			if(!$user) {
				$this->session->unset_userdata("username");
			} else {
				redirect('user');
			}
		}
    }
	// public function generate()
	// {
	// 	$password_hashed = password_hash("tobel123", PASSWORD_DEFAULT);
	// 	$result = $this->db->query("
	// 		INSERT INTO user (id, username, password, name) VALUES('', 'tobel', '$password_hashed', 'Wiji Fiko Teren')
	// 	");
	// 	var_dump($result);
	// }

	public function ajax_login()
	{
		if(!isset($_POST["username"]) || !isset($_POST["password"])) {
			echo "Parameter username or password is not set"; die;
		} else {
			$username = trim($this->input->post("username"));
			$password = trim($this->input->post("password"));
			$result = $this->db->get_where("user", ["username" => $username])->row_array();
			if($result == false){
				echo "Username is not registered"; die;
			} else {
				$matchpassword = password_verify($password, $result["password"]);
				if($matchpassword == false){
					echo "Password is wrong"; die;
				} else {
					$this->session->set_userdata("username", $username);
					echo "success"; die;
				}
			}
		}
	}
}
?>
 <!-- =========================================================
* Daily life of a student
=========================================================
* Github Repository : https://github.com/fiko942/Daily-life-of-a-student
* Website (https://trucatt.tobelsoft.my.id, https://tobelsoft.my.id, https://genic.tobelsoft.my.id, https://daily.tobelsoft.my.id)
* Coded by Wiji Fiko Teren
* Help : https://facebook.com/fiko.tobel/ or https://wa.me/+14127755084/
* Buy me a coffe : 085935099343[Dana, Gopay, Ovo] 
* Thanks for downloading ...
=========================================================
 -->